import  { useState, createContext } from "react";  

export const TodoContext = createContext();  

export const TodoProvider = ({ children }) => {  
    const [tasks, setTasks] = useState([]);  
    const [filter, setFilter] = useState("");  
console.log(tasks);



    const addTask = (title, category) => {  
        const newTask = {  
            id: tasks.length,  
            title, 
            category,
        };  
        setTasks([...tasks, newTask]);  
    };  

    const removeTask = (id) => {  
        const newTasks = tasks.filter((task) => task.id !== id);  
        setTasks(newTasks);  
    };  

    const filteredTasks =        
        filter? tasks.filter((item) => item.category === filter)  
           : tasks;  


    

    return (  
        <TodoContext.Provider value={{ tasks: filteredTasks,filter,setTasks, addTask, removeTask, setFilter }}>  
            {children}  
        </TodoContext.Provider>  
    );  
};