import TaskList from "../../components/taskList/TaskList";


function GroceriesPage() {
  return (
<TaskList/>
  )
}

export default GroceriesPage