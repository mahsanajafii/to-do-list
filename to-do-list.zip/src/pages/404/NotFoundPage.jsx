import Card from "../../components/card/Card"
import Styles from "../../App.module.css";


function NotFoundPage() {
  return (
    <Card style={Styles.container.rightSide} >
        <h1 className="text-5xl w-fit" >This Page Not Found</h1>


    </Card>  

  )
}

export default NotFoundPage