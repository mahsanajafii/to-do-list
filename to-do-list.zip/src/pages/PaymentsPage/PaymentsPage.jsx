import TaskList from "../../components/taskList/TaskList";

function PaymentsPage() {
  return (
<TaskList/>
  )
}

export default PaymentsPage