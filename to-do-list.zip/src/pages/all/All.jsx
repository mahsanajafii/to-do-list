import TaskList from "../../components/taskList/TaskList";

const All = () => {
  return <TaskList />;
};

export default All;
