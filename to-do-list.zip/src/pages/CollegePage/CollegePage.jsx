import TaskList from "../../components/taskList/TaskList";

function CollegePage() {
  return (
    <TaskList />
  )
}

export default CollegePage