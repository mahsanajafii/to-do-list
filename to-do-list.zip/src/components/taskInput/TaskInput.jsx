import { useState } from "react";
import { useContext } from "react";
import { TodoContext } from "../../contexs/TodoProvider";

const TaskInput = () => {
  const [taskInput, setTaskInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("uncategory");
  const [inputError, setInputError] = useState("");

  const categories = ["Groceries", "College", "Payments"];
  const { addTask } = useContext(TodoContext);

  const handleAddTask = (e) => {
    if (e.key === "Enter") {
      if (e.target.value !== "") {
        setInputError("");
        addTask(taskInput, categoryInput);
        setTaskInput("");
        setCategoryInput("uncategory");
      } else {
        setInputError("please enter your task!!!!");
      }

      e.target.value = "";
    }
  };

  return (
    <div className="p-4 w-full">
      <div className="flex flex-row">
        <input
          type="text"
          value={taskInput}
          onChange={(e) => setTaskInput(e.target.value)}
          className="border p-2 w-3/4 rounded-xl mb-2"
          placeholder="Add a new task insdie ‘All’ category"
          onKeyDown={handleAddTask}
        />
        <select
          value={categoryInput}
          onChange={(e) => setCategoryInput(e.target.value)}
          className="border p-2 w-1/4 rounded-xl mb-2 cursor-pointer"
        >
          <option value="">Select a category</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>
      {inputError && <p className="text-black text-sm">{inputError}</p>}
    </div>
  );
};

export default TaskInput;
